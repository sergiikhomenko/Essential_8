﻿namespace task5;
/*
 * Використовуючи Visual Studio, створіть проект за шаблоном Console Application.
 * Реалізуйте програму, яка прийматиме від користувача дату народження і виводити
 * кількість днів до наступного дня народження.
 */
class Program
{
    static void Main(string[] args)
    {
       Console.WriteLine("Введіть дату народження");
       DateTime.TryParse(Console.ReadLine(), out DateTime dateOfBirth);
       
       DateTime dateNow = DateTime.Today;

       DateTime nextBirth = dateOfBirth.AddYears(dateNow.Year - dateOfBirth.Year);
       if (nextBirth<dateNow) 
       {
          nextBirth = nextBirth.AddYears(1);
       }

       int dey = (nextBirth - dateNow).Days;
       Console.WriteLine($"Залишилося до дня народження {dey}");

    }
}