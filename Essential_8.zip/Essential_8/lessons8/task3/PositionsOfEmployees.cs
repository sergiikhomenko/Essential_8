namespace task3;

public enum PositionsOfEmployees
{
    Accountant = 160,
    Director = 100,
    Maid = 40
} 