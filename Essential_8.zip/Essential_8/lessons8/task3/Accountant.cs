namespace task3;
/*
 * Створіть клас Accountant з
 * методом bool AskForBonus (Post worker, int hours), що відображатиме давати
 * співробітнику премію. Якщо співробітник відпрацював більше годин на місяць,
 * то йому належить премія.
 */
public static class Accountant
{
    public static void Bonus(PositionsOfEmployees worker, int hours)
    {
       BonusPrint(AskForBonus( worker, hours)); 
    }

    private static bool AskForBonus(PositionsOfEmployees worker, int hours)
   {
       bool bonus = false;
           if ((PositionsOfEmployees.Accountant == worker)&&(hours > 160))
           { 
               bonus = true;
           }
          if ((PositionsOfEmployees.Director== worker )&&(hours >100))
           {
               bonus = true;
           }
           if ((PositionsOfEmployees.Maid == worker)&&(hours > 40))
           {
               bonus = true;
           }
   return bonus;
   }

   private static void BonusPrint(bool bonus)
   {
       if (bonus)
       {
           Console.WriteLine("Премія доступна");
       }
       else
       {
           Console.WriteLine("Премія не надана");
       }
   }
} 