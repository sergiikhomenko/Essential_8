﻿namespace task2;
/*
 * Використовуючи Visual Studio, створіть проект за шаблоном Console Application.
 * Створіть статичний клас із методом void Print (string stroka, int color),
 * який виводить на екран рядок заданим кольором. Використовуючи перелік,
 * створіть набір кольорів, доступних користувачеві. Введення рядка та вибір
 * кольору надайте користувачеві. 
 */
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Виберіть один з доступних кольорів");

        foreach (var color in Enum.GetValues(typeof(Color)))
        {
            Console.WriteLine($"{(int)color}. {color}");
        }
        string colorSelect = Console.ReadLine();
         
        Console.WriteLine("Введіть рядок для виводу");
        string line = Console.ReadLine();
        
        foreach (var color in Enum.GetValues(typeof(Color)))
        {
            if (color.ToString() == colorSelect)
            {
                ColorConsole.Print(line,Convert.ToInt32((Color)color));
                break;
            }
        }
    }
}
