namespace task2;

public enum Color
{ 
    Black = 0,
    Red = 12,
    Blue = 9
}