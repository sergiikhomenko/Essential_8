namespace task2;
/*
 * Використовуючи Visual Studio, створіть проект за шаблоном Console Application.
 * Створіть статичний клас із методом void Print (string stroka, int color),
 * який виводить на екран рядок заданим кольором. Використовуючи перелік,
 * створіть набір кольорів, доступних користувачеві. Введення рядка та вибір
 * кольору надайте користувачеві.
 */
public static class ColorConsole
{
 public static void Print(string stroka, int color)
 {
  switch (color)
  {
   case 1:
    Console.ForegroundColor = ConsoleColor.Black;
    break;
   case 9:
    Console.ForegroundColor = ConsoleColor.Blue;
    break;
   case 12: Console.ForegroundColor = ConsoleColor.Red;
    break;
  }
  Console.WriteLine(stroka);
  }
}